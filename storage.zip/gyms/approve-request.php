<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";
require_once "../utils/mail.php"; // 👈 email helper

$auth = authenticate();
$GLOBALS['auth_user'] = $auth;
requireRole(['super_admin']);

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['request_id']) || empty($data['action'])) {
    http_response_code(400);
    echo json_encode(["message"=>"Invalid request"]);
    exit;
}

$db = new Database();
$conn = $db->connect();

// fetch request
$stmt = $conn->prepare("SELECT * FROM gym_requests WHERE id=:id");
$stmt->execute([":id"=>$data['request_id']]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
    http_response_code(404);
    echo json_encode(["message"=>"Request not found"]);
    exit;
}

/* ================= REJECT ================= */

if ($data['action'] === 'rejected') {
    $reason = $data['reason'] ?? 'Not specified';

    $stmt = $conn->prepare(
      "UPDATE gym_requests
       SET status='rejected', rejection_reason=:reason
       WHERE id=:id"
    );
    $stmt->execute([
      ":reason"=>$reason,
      ":id"=>$request['id']
    ]);

    sendMail(
      $request['owner_email'],
      "Gym Registration Rejected",
      "Sorry, your gym request was rejected.<br><br>Reason:<br><b>$reason</b>"
    );

    echo json_encode(["status"=>true,"message"=>"Request rejected"]);
    exit;
}

/* ================= APPROVE ================= */

$conn->beginTransaction();

// create gym
$slug = strtolower(preg_replace('/\s+/', '', $request['gym_name']));

$stmt = $conn->prepare(
  "INSERT INTO gyms (name, slug, email, status)
   VALUES (:name,:slug,:email,'active')"
);
$stmt->execute([
  ":name"=>$request['gym_name'],
  ":slug"=>$slug,
  ":email"=>$request['owner_email']
]);
$gym_id = $conn->lastInsertId();

// generate password
$password = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"),0,8);

// create gym admin
$stmt = $conn->prepare(
  "INSERT INTO users
   (gym_id, name, email, password, role, status, force_password_change)
   VALUES (:gym,:name,:email,:password,'gym_admin','active',1)"
);

$stmt->execute([
  ":gym"=>$gym_id,
  ":name"=>$request['owner_name'],
  ":email"=>$request['owner_email'],
  ":password"=>password_hash($password,PASSWORD_DEFAULT)
]);

// update request
$stmt = $conn->prepare(
  "UPDATE gym_requests SET status='approved' WHERE id=:id"
);
$stmt->execute([":id"=>$request['id']]);
/* ================= AUTO CREATE DEFAULT GYM PAGES ================= */

// page slug => template name
$defaultPages = [
  'home'    => 'Gym Home',
  'about'   => 'Gym About',
  'contact' => 'Gym Contact',
];

$templateStmt = $conn->prepare(
  "SELECT id FROM templates WHERE name = :name AND type = 'gym' LIMIT 1"
);

$pageInsertStmt = $conn->prepare("
  INSERT INTO pages
  (site_type, gym_id, slug, template_id, page_data_json)
  VALUES ('gym', :gym_id, :slug, :template_id, '{}')
");

foreach ($defaultPages as $pageSlug => $templateName) {

    $templateStmt->execute([":name" => $templateName]);
    $template = $templateStmt->fetch(PDO::FETCH_ASSOC);

    if (!$template) {
        throw new Exception("Gym template not found: $templateName");
    }

    $pageInsertStmt->execute([
      ":gym_id"      => $gym_id,
      ":slug"        => $pageSlug,
      ":template_id" => $template['id']
    ]);
}


$conn->commit();

// send approval email
$loginUrl = "http://localhost:5173/";

sendMail(
  $request['owner_email'],
  "Gym Approved – Login Details",
  "
  Your gym has been approved 🎉<br><br>
  <b>Login URL:</b> $loginUrl<br>
  <b>Email:</b> {$request['owner_email']}<br>
  <b>Password:</b> $password<br><br>
  Please login and change your password.
  "
);

echo json_encode(["status"=>true,"message"=>"Gym approved"]);

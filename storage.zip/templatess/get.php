<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";

$id = $_GET['id'] ?? null;
if (!$id) {
  http_response_code(400);
  echo json_encode(["message"=>"Template id required"]);
  exit;
}

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare(
  "SELECT * FROM templates WHERE id=:id AND status='active'"
);
$stmt->execute([":id"=>$id]);

echo json_encode([
  "status"=>true,
  "data"=>$stmt->fetch(PDO::FETCH_ASSOC)
]);

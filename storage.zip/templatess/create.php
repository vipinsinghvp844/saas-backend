<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";

$auth = authenticate();
$GLOBALS['auth_user'] = $auth;
requireRole(['super_admin']);

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['name']) || empty($data['structure'])) {
    http_response_code(400);
    echo json_encode(["message"=>"Name & structure required"]);
    exit;
}

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare(
  "INSERT INTO templates (name,type,structure_json)
   VALUES (:name,'platform',:structure)"
);

$stmt->execute([
  ":name"=>$data['name'],
  ":structure"=>json_encode($data['structure'])
]);

echo json_encode([
  "status"=>true,
  "message"=>"Template created"
]);

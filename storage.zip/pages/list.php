<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";

$auth = authenticate();
$GLOBALS['auth_user'] = $auth;
requireRole(['super_admin']);

$db = new Database();
$conn = $db->connect();

$stmt = $conn->query(
  "SELECT p.id,p.slug,t.name AS template,p.status
   FROM pages p
   JOIN templates t ON t.id=p.template_id
   WHERE p.site_type='platform'"
);

echo json_encode([
  "status"=>true,
  "data"=>$stmt->fetchAll(PDO::FETCH_ASSOC)
]);

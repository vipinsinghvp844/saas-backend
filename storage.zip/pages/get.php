<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";

$auth = authenticate();
$GLOBALS['auth_user'] = $auth;
requireRole(['super_admin']);

$id = $_GET['id'] ?? null;
if (!$id) {
  http_response_code(400);
  echo json_encode(["message"=>"Page id required"]);
  exit;
}

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare(
  "SELECT p.id,p.slug,p.page_data_json,t.structure_json
   FROM pages p
   JOIN templates t ON t.id=p.template_id
   WHERE p.id=:id"
);
$stmt->execute([":id"=>$id]);

echo json_encode([
  "status"=>true,
  "data"=>$stmt->fetch(PDO::FETCH_ASSOC)
]);

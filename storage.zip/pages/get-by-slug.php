<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";

$slug = $_GET['slug'] ?? null;
if (!$slug) {
    http_response_code(400);
    echo json_encode(["message"=>"Slug required"]);
    exit;
}

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare(
  "SELECT p.slug,p.page_data_json,t.structure_json
   FROM pages p
   JOIN templates t ON t.id=p.template_id
   WHERE p.slug=:slug AND p.status='active'"
);
$stmt->execute([":slug"=>$slug]);

$page = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$page) {
    http_response_code(404);
    echo json_encode(["message"=>"Page not found"]);
    exit;
}

echo json_encode([
  "status"=>true,
  "data"=>$page
]);

<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";

$auth = authenticate();
$GLOBALS['auth_user'] = $auth;
requireRole(['super_admin']);

$data = json_decode(file_get_contents("php://input"), true);

if (
    empty($data['slug']) ||
    empty($data['template_id'])
) {
    http_response_code(400);
    echo json_encode(["message" => "Slug & template required"]);
    exit;
}

$db = new Database();
$conn = $db->connect();

// prevent duplicate slug
$stmt = $conn->prepare(
  "SELECT id FROM pages WHERE slug=:slug AND site_type='platform'"
);
$stmt->execute([":slug"=>$data['slug']]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(["message"=>"Slug already exists"]);
    exit;
}

$stmt = $conn->prepare(
  "INSERT INTO pages (site_type,slug,template_id,page_data_json)
   VALUES ('platform',:slug,:template,:data)"
);

$stmt->execute([
  ":slug"=>$data['slug'],
  ":template"=>$data['template_id'],
  ":data"=>json_encode($data['page_data'] ?? [])
]);

echo json_encode([
  "status"=>true,
  "message"=>"Page created"
]);

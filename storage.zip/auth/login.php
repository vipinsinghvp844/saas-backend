<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../config/jwt.php"; // createJWT()

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['email']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode([
        "status" => false,
        "message" => "Email and password required"
    ]);
    exit;
}

$db = new Database();
$conn = $db->connect();

/* ==========================
   GET USER
========================== */
$sql = "SELECT 
            id,
            gym_id,
            first_name,
            last_name,
            email,
            phone,
            password,
            role,
            status,
            force_password_change
        FROM users
        WHERE email = :email
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bindParam(":email", $data['email']);
$stmt->execute();

$user = $stmt->fetch(PDO::FETCH_ASSOC);

/* ==========================
   INVALID CREDENTIALS
========================== */
if (!$user || !password_verify($data['password'], $user['password'])) {
    http_response_code(401);
    echo json_encode([
        "status" => false,
        "message" => "Invalid credentials"
    ]);
    exit;
}

/* ==========================
   USER STATUS CHECK
========================== */
if ($user['status'] !== 'active') {
    http_response_code(403);
    echo json_encode([
        "status" => false,
        "message" => "Account blocked"
    ]);
    exit;
}

/* ==========================
   🏢 GYM STATUS CHECK
   (ONLY FOR GYM ADMIN)
========================== */
if ($user['role'] === 'gym_admin') {

    $stmt = $conn->prepare("
        SELECT status 
        FROM gyms 
        WHERE id = :gym_id
        LIMIT 1
    ");
    $stmt->execute([
        ":gym_id" => $user['gym_id']
    ]);

    $gym = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$gym || $gym['status'] !== 'active') {
        http_response_code(403);
        echo json_encode([
            "status" => false,
            "message" => "Your gym is inactive. Please contact support."
        ]);
        exit;
    }
}

/* ==========================
   JWT CREATE
========================== */
$token = createJWT([
    "id"      => $user['id'],
    "gym_id" => $user['gym_id'],
    "role"   => $user['role']
]);

echo json_encode([
    "status" => true,
    "token"  => $token,
    "user"   => [
        "id" => $user['id'],
        "role" => $user['role'],
        "force_password_change" => (int)$user['force_password_change']
    ]
]);

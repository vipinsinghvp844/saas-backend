<?php
require_once "../config/cors.php";
require_once "../config/db.php";
require_once "../middleware/auth.php";

$auth = authenticate();

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("
  SELECT id, name, email, role, avatar
  FROM users
  WHERE id = :id
");
$stmt->execute([":id" => $auth['id']]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
  "status" => true,
  "data" => $user
]);

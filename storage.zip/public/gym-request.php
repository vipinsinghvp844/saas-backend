<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";

$data = json_decode(file_get_contents("php://input"), true);

if (
    empty($data['gym_name']) ||
    empty($data['owner_name']) ||
    empty($data['owner_email'])
) {
    http_response_code(400);
    echo json_encode(["message" => "Required fields missing"]);
    exit;
}

$db = new Database();
$conn = $db->connect();

// prevent duplicate request
$stmt = $conn->prepare(
  "SELECT id FROM gym_requests WHERE owner_email=:email AND status='pending'"
);
$stmt->execute([":email"=>$data['owner_email']]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(["message"=>"Request already pending"]);
    exit;
}

$stmt = $conn->prepare(
  "INSERT INTO gym_requests (gym_name, owner_name, owner_email, phone, plan)
   VALUES (:gym,:owner,:email,:phone,:plan)"
);

$stmt->execute([
  ":gym"=>$data['gym_name'],
  ":owner"=>$data['owner_name'],
  ":email"=>$data['owner_email'],
  ":phone"=>$data['phone'] ?? null,
  ":plan"=>$data['plan'] ?? 'basic'
]);

echo json_encode([
  "status"=>true,
  "message"=>"Request submitted successfully. We will contact you."
]);

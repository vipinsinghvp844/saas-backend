<?php
require_once "../config/cors.php";
header("Content-Type: application/json");

require_once "../config/db.php";
require_once "../middleware/auth.php";
require_once "../middleware/roleGuard.php";

$auth_user = authenticate();
$GLOBALS['auth_user'] = $auth_user;

requireRole(['super_admin']);

$db = new Database();
$conn = $db->connect();

// Stats
$totalGyms = $conn->query("SELECT COUNT(*) FROM gyms")->fetchColumn();
$activeGyms = $conn->query("SELECT COUNT(*) FROM gyms WHERE status='active'")->fetchColumn();
$totalUsers = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Latest gyms
$stmt = $conn->prepare("
    SELECT id, name, slug, created_at
    FROM gyms
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->execute();
$latestGyms = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => true,
    "data" => [
        "total_gyms" => (int)$totalGyms,
        "active_gyms" => (int)$activeGyms,
        "total_users" => (int)$totalUsers,
        "latest_gyms" => $latestGyms
    ]
]);
